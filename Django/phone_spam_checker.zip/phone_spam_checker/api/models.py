from django.db import models

# Create your models here.

class Contact(models.Model):
    name = models.CharField(max_length=255)
    contact_type = models.CharField(max_length=255) # Contact type can be phone, office, home etc.
    phone_number = models.CharField(max_length=20)
    email = models.EmailField(default = '-')
    created_at = models.DateTimeField(auto_now_add = True)

class SpamMark(models.Model):   
    phone_number = models.CharField(max_length = 20)
    spam_text = models.CharField(max_length = 500, blank = True)
    created_at = models.DateTimeField(auto_now_add = True)

class User(models.Model):
    name = models.CharField(max_length = 255)
    phone_number = models.CharField(max_length = 20, unique = True)
    email = models.EmailField(default = '-')
    password = models.CharField(max_length = 15)
    contacts = models.ManyToManyField(Contact, default = list())
    spams_marked = models.ManyToManyField(SpamMark, default = list())
    created_at = models.DateTimeField(auto_now_add = True)