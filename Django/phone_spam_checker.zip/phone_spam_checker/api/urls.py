# api/urls.py
from django.urls import path
from api.views import register_user, mark_as_spam, save_contacts_for_user, search_user

urlpatterns = [
    path('register', register_user, name = 'register_user'),
    path('mark_spam', mark_as_spam, name = 'mark_as_spam'),
    path('save_contacts_for_user', save_contacts_for_user, name = 'save_contacts_for_user'),
    path('search', search_user, name = 'search_user'),
]
