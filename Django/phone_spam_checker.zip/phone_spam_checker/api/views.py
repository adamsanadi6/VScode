from django.http import JsonResponse
from rest_framework.parsers import JSONParser
from api.models import User, Contact, SpamMark
from django.db.models import Q

# Create your views here.

def is_user_exists(phone_number, email):
    try:
        is_exist = User.objects.filter(phone_number = phone_number).exists()
        if not is_exist and email:
            is_exist = existing_user.filter(email = email).exists()
        return is_exist
    except Exception as e:
        return False

def register_user(request):

    json_request = JSONParser().parse(request)
    '''
        It should be the Post method and the data should be in below format:
            {
                'name': 'user name',
                'phone_number': '9874563210',
                'email': 'user@example.com'(optional),
                'password': 'password'(maximum length 15)
            }
    '''

    # Checking for name and phone number
    name = json_request.get('name')
    phone_number = json_request.get('phone_number')
    email = json_request.get('email')
    password = json_request.get('password')
    
    if not name or not phone_number or not password:
        return JsonResponse({'error': 'Name, phone number and password are required!!!'}, status = 400)

    # Checking if a user is already exist with the same phone number or the email id.
    if is_user_exists(phone_number, email):
        return JsonResponse({'error': 'User with the same phone number or email already exists!!!'}, status = 400)

    try:
        user = User.objects.create(**json_request)
        return JsonResponse({'message': 'User registered successfully!!!'}, status = 201)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

def mark_as_spam(request):

    json_request = JSONParser().parse(request)

    '''
        It should be the Post method and the data should be in below format:
            {
                'phone_number': '9874563210',
                'spam_text': 'This Number is Spam'
            }
    '''
    
    phone_number = json_request.get('phone_number')
    if not phone_number:
        return JsonResponse({'error': 'Phone number is required!!!'}, status = 400)

    # We need to check which user us marking the phone number as spam. We can get this from cookie/ token. For now I'm assuming, users phone number as 7899115929
    try:

        # Check if the User is already marked this number as Spam and phone number already exists in the global spam marks.
        existing_spam = User.objects.filter(**{'phone_number': '7899115929','spams_marked__phone_number': phone_number})
        if existing_spam.exists():
            return JsonResponse({'error': 'You have already marked this phone number as spam!!!'}, status = 400)

        spam_text = json_request.get('spam_text', '')

        # Create the SpamMark object for the phone number
        spam_mark = SpamMark.objects.create(**{'phone_number': phone_number, 'spam_text': spam_text})

        # Get the user with the default phone_number '7899115929' and add the created SpamMark object to the user's spams_marked field
        default_phone_user = User.objects.get(phone_number = '7899115929')
        default_phone_user.spams_marked.add(spam_mark)

        return JsonResponse({'message': 'Phone number marked as spam successfully!!!'}, status = 201)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status = 500)

def save_contacts_for_user(request):
    try:
        # Get or create the user with the given phone number
        user_phone_number = '7899115929'  # Replace this with the desired user's phone number
        user, created = User.objects.get_or_create(phone_number=user_phone_number)

        # Create contacts and associate them with the user
        contact1 = Contact.objects.create(contact_name='John Doe', contact_type='phone', contact_phone_number='1234567890')
        contact2 = Contact.objects.create(contact_name='Jane Smith', contact_type='home', contact_phone_number='9876543210')
        contact3 = Contact.objects.create(contact_name='Dom Jane Smith', contact_type='home', contact_phone_number='9833343210')
        contact4 = Contact.objects.create(contact_name='Logan Smith', contact_type='home', contact_phone_number='9876643210')
        contact5 = Contact.objects.create(contact_name='Max Doe', contact_type='home', contact_phone_number='9876543270')


        # Add the contacts to the user's contacts (ManyToMany) field
        user.contacts.add(contact1)
        user.contacts.add(contact2)
        user.contacts.add(contact3)
        user.contacts.add(contact4)
        user.contacts.add(contact5)


        return JsonResponse({'message': 'Contacts saved successfully for the user with phone number \'7899115929\'!!!'})
    except Exception as e:
        return JsonResponse({"error": str(e)}, status = 500)

def calculate_spam_likelihood(phone_number):
    try:
        # Retrieving all the spam marks associated with the given phone number
        spam_marks = SpamMark.objects.filter(phone_number=phone_number)

        # Calculating the spam likelihood based on the number of spam marks
        total_spam_marks = spam_marks.count()
        if total_spam_marks > 0:
            # For calculating the spam likelihood many things should be considered like The number of spam marks, The recency of spam marks, The source of spam marks, location etc. For That we should design Machine Learning Model to calculate the spam likelihood. For Simplicity I'm deviding the total number of spam marks by 10
            spam_likelihood = total_spam_marks / 10.0
        else:
            spam_likelihood = 0.0

        return spam_likelihood
    except Exception as e:
        return 0.0  # Return 0.0 as a default value in case of any errors

def check_user_in_contacts(contacts, query, results):

    for contact in contacts:
        user_name = contact.name
        if contact.phone_number == query or user_name == query or user_name.startswith(query) or query in user_name:
            result_data = {"name": user_name, "phone_number": contact.phone_number, "spam_likelihood": calculate_spam_likelihood(contact.phone_number),  "email": contact.email}
            results.append(result_data)

def search_users_utils(query, pk, model_name):
    # There are two ways first one is also correct since we want the result like "Results should first show people whose names start with the search query, and then people whose names contain but don’t start with the search query."  So we need to follow the second way.
    
    # First method
    # user_results = model_name.objects.filter(Q(name = query) | Q(phone_number = query) | Q(name__starts_with = query) | Q(name__contains = query))

    # Second method
    name_results_exact = model_name.objects.filter(name__iexact = query).exclude(pk = pk) # Exact name match
    phone_results_exact = model_name.objects.filter(phone_number = query).exclude(pk = pk) # Exact phone number match
    name_results_startswith = model_name.objects.filter(name__istartswith = query).exclude(pk = pk) # Name starts with given name
    name_results_contains = model_name.objects.filter(name__icontains = query).exclude(pk = pk) # Name contains given name
    user_results = (name_results_exact | phone_results_exact | name_results_startswith | name_results_contains).distinct() # Removing the duplicates using union operator and distinct method.

    return user_results

def search_user(request):
    query = request.GET.get('query')

    if not query:
        return JsonResponse({'error': 'Search query is required!!!'}, status = 400)

    # Get or create the user with the given phone number
    user_phone_number = '7899115929'  # Replace this with the desired user's phone number
    user, created = User.objects.get_or_create(phone_number = user_phone_number)

    results = list()
    # Searching in the users contacts
    if user:
        check_user_in_contacts(user.contacts.all(), query, results)
        if len(results) > 0:
            return JsonResponse({'results': results}, status = 200)

    # Searching by name and phone number in registration
    registered_user_results = search_users_utils(query, user.pk, User)

    # Tagging the mail to the results since the search found from registered users.
    phone_numbers = list() # For avoiding the duplicate entries.
    for user in registered_user_results:

        result_data = {"name": user.name, "phone_number": user.phone_number, "spam_likelihood": calculate_spam_likelihood(user.phone_number),  "email": user.email}
        results.append(result_data)
        phone_numbers.append(user.phone_number)

    # SEarching in Contacts
    contacts_user_results = search_users_utils(query, user.pk, Contact)

    # Tagging only name, phone number and spam likelihood but not email to the results since the search found from contants.
    for user in contacts_user_results:
    
        if user.phone_number in phone_numbers: # if the result is already added to the results with the same phone number then skip it.
            continue

        result_data = {"name": user.name, "phone_number": user.phone_number, "spam_likelihood": calculate_spam_likelihood(user.phone_number)}
        results.append(result_data)
        phone_numbers.append(user.phone_number)

    return JsonResponse({"results": results}, status = 200)